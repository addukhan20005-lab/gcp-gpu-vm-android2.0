package com.example.gcpvmmanager.data

/**
 * Editable planning estimates only (USD/hour). These are deliberately not presented as live prices.
 * Update from official Google Cloud pricing before relying on them. Windows license, region,
 * Spot pricing, disks, networking, and discounts may change the real total substantially.
 */
object CostEstimates {
    const val N1_STANDARD_4_BASE_USD_HOUR = 0.19
    const val N1_STANDARD_8_BASE_USD_HOUR = 0.38
    const val TESLA_T4_USD_HOUR = 0.35
    fun estimate(machineType: String, gpu: Boolean): Double {
        val cpu = if (machineType == "n1-standard-8") N1_STANDARD_8_BASE_USD_HOUR else N1_STANDARD_4_BASE_USD_HOUR
        return cpu + if (gpu) TESLA_T4_USD_HOUR else 0.0
    }
}
