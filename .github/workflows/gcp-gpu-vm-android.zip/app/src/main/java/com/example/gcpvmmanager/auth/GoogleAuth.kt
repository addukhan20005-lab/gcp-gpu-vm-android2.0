package com.example.gcpvmmanager.auth

import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.gms.auth.api.identity.AuthorizationClient
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Scope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class AuthResult(val idToken: String, val email: String?)

class GoogleAuth(private val context: Context) {
    private val credentialManager = CredentialManager.create(context)
    private val authorizationClient: AuthorizationClient = Identity.getAuthorizationClient(context)
    private val computeScope = Scope("https://www.googleapis.com/auth/compute")

    suspend fun signIn(activity: Activity, webClientId: String): AuthResult {
        val option = GetGoogleIdOption.Builder()
            .setServerClientId(webClientId)
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val response = credentialManager.getCredential(activity, request)
        val credential = response.credential
        if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            error("Google sign-in did not return a Google ID credential.")
        }
        val id = GoogleIdTokenCredential.createFrom(credential.data)
        return AuthResult(id.idToken, id.id)
    }

    suspend fun authorize(activity: Activity, idToken: String, silent: Boolean = false): String =
        suspendCancellableCoroutine { cont ->
            val request = AuthorizationRequest.builder()
                .setRequestedScopes(listOf(computeScope))
                .build()
            val task = if (silent) authorizationClient.authorize(request) else authorizationClient.authorize(request)
            task.addOnSuccessListener { result ->
                val access = result.accessToken
                if (!access.isNullOrBlank()) cont.resume(access)
                else if (result.hasResolution()) {
                    if (silent) cont.resumeWithException(IllegalStateException("Silent authorization needs user interaction. Please sign in again."))
                    else cont.resumeWithException(IllegalStateException("Authorization requires UI resolution; retry sign-in."))
                } else cont.resumeWithException(IllegalStateException("Google did not return a Compute Engine access token."))
            }.addOnFailureListener { e -> if (cont.isActive) cont.resumeWithException(e) }
        }
}
