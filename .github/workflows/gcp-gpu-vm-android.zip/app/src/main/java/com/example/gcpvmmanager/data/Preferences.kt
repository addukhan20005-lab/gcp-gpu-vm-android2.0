package com.example.gcpvmmanager.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "cloud_vm_settings")
class Preferences(private val context: Context) {
    private val projectKey = stringPreferencesKey("project_id")
    private val zoneKey = stringPreferencesKey("zone")
    val settings = context.dataStore.data.map { it[projectKey].orEmpty() to (it[zoneKey] ?: "us-central1-a") }
    suspend fun save(project: String, zone: String) {
        context.dataStore.edit { it[projectKey] = project; it[zoneKey] = zone }
    }
}
