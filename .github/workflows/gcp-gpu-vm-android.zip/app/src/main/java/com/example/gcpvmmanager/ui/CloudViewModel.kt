package com.example.gcpvmmanager.ui

import android.app.Application
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.gcpvmmanager.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPublicKey
import java.security.spec.MGF1ParameterSpec
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource

data class UiState(
    val project: String = "", val zone: String = "us-central1-a",
    val signedIn: Boolean = false, val loading: Boolean = false, val operation: String? = null,
    val vms: List<Vm> = emptyList(), val message: String? = null, val error: String? = null,
    val showCreate: Boolean = false, val createName: String = "win-gpu-vm",
    val machineType: String = "n1-standard-4", val gpu: Boolean = true, val spot: Boolean = false,
    val diskGb: String = "80", val firewallIp: String = "", val firewallRestrict: Boolean = true,
    val firewallDialog: Boolean = false, val selectedVm: Vm? = null,
    val passwordBusy: Boolean = false, val passwordText: String? = null, val passwordShown: Boolean = false,
    val passwordVm: Vm? = null, val stopTimerHours: Int = 4, val stopTimerAlsoStops: Boolean = false
)

class CloudViewModel(app: Application) : AndroidViewModel(app) {
    private val api = ApiFactory.create()
    private val prefs = Preferences(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var accessToken: String? = null // Never persisted or logged.
    private var googleIdToken: String? = null
    private var keyPair: KeyPair? = null
    private var serialOffset: Long = 0L
    private var refreshJob: Job? = null

    init { viewModelScope.launch { prefs.settings.collect { (p,z) -> _state.update { it.copy(project=p,zone=z) } } } }

    fun updateProject(v: String) = _state.update { it.copy(project=v) }
    fun updateZone(v: String) { _state.update { it.copy(zone=v) }; persist() }
    fun persist() { viewModelScope.launch { val s = _state.value; prefs.save(s.project.trim(),s.zone.trim()) } }
    fun updateMessage(v: String?) = _state.update { it.copy(message=v,error=null) }
    fun dismissMessage() = _state.update { it.copy(message=null,error=null) }
    fun setCreateVisible(v: Boolean) = _state.update { it.copy(showCreate=v) }
    fun updateCreateName(v: String) = _state.update { it.copy(createName=v) }
    fun updateMachine(v: String) = _state.update { it.copy(machineType=v) }
    fun updateGpu(v: Boolean) = _state.update { it.copy(gpu=v) }
    fun updateSpot(v: Boolean) = _state.update { it.copy(spot=v) }
    fun updateDisk(v: String) = _state.update { it.copy(diskGb=v) }
    fun setFirewallDialog(v: Boolean) = _state.update { it.copy(firewallDialog=v) }
    fun updateFirewallIp(v: String) = _state.update { it.copy(firewallIp=v) }
    fun updateFirewallRestrict(v: Boolean) = _state.update { it.copy(firewallRestrict=v) }
    fun selectVm(vm: Vm?) = _state.update { it.copy(selectedVm=vm) }

    fun setAuth(idToken: String, access: String) {
        googleIdToken = idToken; accessToken = access
        _state.update { it.copy(signedIn=true,message="Signed in. Access token is held in memory only.",error=null) }
        refresh()
    }
    fun signOut() {
        accessToken=null; googleIdToken=null; keyPair=null
        _state.update { it.copy(signedIn=false,vms=emptyList(),selectedVm=null,passwordText=null,passwordVm=null,passwordBusy=false,message="Signed out; in-memory credentials cleared.") }
    }

    private suspend fun token(): String {
        val value = accessToken
        if (value.isNullOrBlank()) throw IllegalStateException("Your Google access token expired or is missing. Sign in again.")
        return value
    }
    private fun auth() = "Bearer ${accessToken ?: error("Your Google access token expired or is missing. Sign in again.")}"
    private fun project() = _state.value.project.trim().also { require(it.isNotBlank()) { "Enter your Google Cloud Project ID." } }
    private fun zone() = _state.value.zone.trim().also { require(it.isNotBlank()) { "Enter a zone." } }

    private fun <T> response(response: retrofit2.Response<T>): T {
        if (response.isSuccessful) return response.body() ?: error("Google API returned an empty response.")
        val raw = response.errorBody()?.string().orEmpty()
        val msg = runCatching { JsonCodec.decodeFromString<ApiError>(raw).error?.message }.getOrNull().orEmpty()
        val text = "$msg $raw".lowercase()
        val friendly = when {
            response.code() == 401 -> "Google access token expired. Sign in again to refresh authorization."
            response.code() == 403 && (text.contains("billing") || text.contains("billing account")) -> "Billing is disabled for this project. Enable billing in Google Cloud Console."
            response.code() == 403 && (text.contains("compute.googleapis.com") || text.contains("api has not been used") || text.contains("not enabled")) -> "Compute Engine API is not enabled. Enable compute.googleapis.com in your project."
            response.code() == 403 -> "Permission denied. Check project IAM roles, billing status, and API enablement."
            text.contains("zone_resource_pool_exhausted") -> "This zone has no available capacity for the requested VM. Try another supported zone."
            text.contains("quota") || text.contains("resource_exhausted") -> "Quota exceeded. Request T4 GPU quota and check regional CPU, disk and IP quotas."
            else -> msg.ifBlank { "Google Compute API request failed (HTTP ${response.code()})." }
        }
        error(friendly)
    }

    fun refresh() = runTask {
        val p=project(); val z=zone()
        val result=response(api.listInstances(auth(),p,z))
        _state.update { it.copy(vms=result.items.map { dto -> dto.toVm(z) },loading=false,error=null) }
    }
    fun create() = runTask {
        val s=_state.value; val p=project(); val z=s.zone.trim()
        require(s.createName.matches(Regex("^[a-z]([-a-z0-9]*[a-z0-9])?$")) && s.createName.length <= 63) { "VM name must be 1–63 characters, start with a lowercase letter, and use lowercase letters, numbers, or hyphens." }
        val disk=s.diskGb.toLongOrNull() ?: 0L
        require(disk>=50) { "Boot disk must be at least 50 GB." }
        val scheduling = if (s.gpu || s.spot) Scheduling("TERMINATE",false,if(s.spot)"SPOT" else null,if(s.spot)"STOP" else null) else Scheduling("MIGRATE",true)
        val body=InstanceCreateRequest(
            name=s.createName, machineType="zones/$z/machineTypes/${s.machineType}",
            disks=listOf(DiskConfig(true,true,InitializeParams("projects/windows-cloud/global/images/family/windows-2022",disk.toString(),"zones/$z/diskTypes/pd-balanced"))),
            networkInterfaces=listOf(NetworkConfig("global/networks/default",listOf(NetworkAccessConfig("External NAT","ONE_TO_ONE_NAT")))),
            guestAccelerators=if(s.gpu) listOf(GuestAccelerator("zones/$z/acceleratorTypes/nvidia-tesla-t4",1)) else null,
            tags=TagsDto(listOf("rdp")), metadata=MetadataDto(items=emptyList()), scheduling=scheduling
        )
        val op=response(api.createInstance(auth(),p,z,body))
        awaitOperation(op,z)
        _state.update { it.copy(showCreate=false,message="VM ${s.createName} created. Windows may take several minutes to initialize.") }
        refreshInternal()
    }
    fun action(action: String, vm: Vm) = runTask {
        val p=project()
        val op=when(action) {
            "start" -> response(api.startInstance(auth(),p,vm.zone,vm.name))
            "stop" -> response(api.stopInstance(auth(),p,vm.zone,vm.name))
            "delete" -> response(api.deleteInstance(auth(),p,vm.zone,vm.name))
            else -> error("Unknown VM action.")
        }
        awaitOperation(op,vm.zone)
        _state.update { it.copy(selectedVm=null,message="${vm.name}: $action completed.") }
        refreshInternal()
    }
    private suspend fun refreshInternal() {
        val s=_state.value
        val result=response(api.listInstances(auth(),project(),zone()))
        _state.update { it.copy(vms=result.items.map { dto -> dto.toVm(s.zone) },loading=false) }
    }
    private suspend fun awaitOperation(op: OperationDto, opZone: String?) {
        _state.update { it.copy(operation=op.name) }
        repeat(90) {
            delay(2000)
            val result=if(opZone==null) response(api.globalOperation(auth(),project(),op.name)) else response(api.zoneOperation(auth(),project(),opZone,op.name))
            if(result.status=="DONE") {
                val error=result.error?.errors?.joinToString { it.message.orEmpty() }.orEmpty()
                if(error.isNotBlank()) throw IllegalStateException(error)
                _state.update { it.copy(operation=null) }; return
            }
        }
        _state.update { it.copy(operation=null) }
        error("Operation is still running. Refresh the VM list to check its status.")
    }

    fun createFirewall() = runTask {
        val s=_state.value; val p=project()
        val ranges=if(s.firewallRestrict) listOf("${s.firewallIp.trim()}/32") else listOf("0.0.0.0/0")
        if(s.firewallRestrict) require(s.firewallIp.matches(Regex("^(\\d{1,3}\\.){3}\\d{1,3}$"))) { "Enter a valid public IPv4 address." }
        val body=FirewallDto(name="allow-rdp-from-my-ip",sourceRanges=ranges)
        val list=response(api.listFirewalls(auth(),p))
        val existing=list.items.firstOrNull { it.name==body.name }
        val op=if(existing==null) response(api.createFirewall(auth(),p,body)) else response(api.patchFirewall(auth(),p,body.name,body))
        awaitOperation(op,null)
        _state.update { it.copy(firewallDialog=false,message="RDP firewall rule saved for ${ranges.joinToString()}.") }
    }

    fun getWindowsPassword(vm: Vm) = runTask {
        _state.update { it.copy(passwordBusy=true,passwordVm=vm,passwordText=null,passwordShown=false) }
        serialOffset=0
        val pair=KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        keyPair=pair
        val pub=pair.public as RSAPublicKey
        val modulus=Base64.encodeToString(unsigned(pub.modulus.toByteArray()),Base64.NO_WRAP)
        val exponent=Base64.encodeToString(unsigned(pub.publicExponent.toByteArray()),Base64.NO_WRAP)
        val username="vmuser"
        val email= "windows-vm-user"
        val expire=System.currentTimeMillis()+60*60*1000
        val metadataValue=Json.encodeToString(listOf(mapOf("userName" to username,"modulus" to modulus,"exponent" to exponent,"email" to email,"expireOn" to expire)))
        val instance=response(api.getInstance(auth(),project(),vm.zone,vm.name))
        val old=instance.metadata?.items.orEmpty().filterNot { it.key=="windows-keys" }
        val items=old+MetadataItem("windows-keys",metadataValue)
        val op=response(api.setMetadata(auth(),project(),vm.zone,vm.name,MetadataRequest(instance.metadata?.fingerprint,items)))
        awaitOperation(op,vm.zone)
        var encrypted:String?=null
        repeat(36) {
            delay(5000)
            val serial=response(api.serialPort(auth(),project(),vm.zone,vm.name,4,serialOffset))
            serialOffset=serial.next?.toLongOrNull() ?: (serialOffset+serial.contents.length)
            val lines=serial.contents.lines()
            val line=lines.lastOrNull { it.contains(modulus) && it.contains("encryptedPassword") }
            if(line!=null) {
                encrypted=Regex("encryptedPassword\\s*[:=]\\s*[\"']?([A-Za-z0-9+/=_-]{40,})").find(line)?.groupValues?.getOrNull(1)
            }
            if(!encrypted.isNullOrBlank()) return@repeat
        }
        val cipherText=encrypted ?: error("Timed out waiting for a matching encryptedPassword on serial port 4. Wait for Windows initialization and retry.")
        val cipher=Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding")
        cipher.init(Cipher.DECRYPT_MODE,pair.private,OAEPParameterSpec("SHA-1","MGF1",MGF1ParameterSpec.SHA1,PSource.PSpecified.DEFAULT))
        val password=String(cipher.doFinal(Base64.decode(cipherText,Base64.DEFAULT))).trimEnd('\u0000','\r','\n')
        _state.update { it.copy(passwordText=password,passwordShown=true,passwordBusy=false,message="Password decrypted locally. Copy it now; it is not saved.") }
    }
    private fun unsigned(bytes: ByteArray): ByteArray = if(bytes.size>1 && bytes[0]==0.toByte()) bytes.copyOfRange(1,bytes.size) else bytes
    fun togglePasswordShown() = _state.update { it.copy(passwordShown=!it.passwordShown) }
    fun clearPassword() { keyPair=null; _state.update { it.copy(passwordText=null,passwordVm=null,passwordShown=false,passwordBusy=false) } }

    private fun runTask(block: suspend () -> Unit) {
        viewModelScope.launch {
            _state.update { it.copy(loading=true,error=null,message=null) }
            try { block() }
            catch(e: Exception) {
                val msg=if(e is java.io.IOException) "No network connection. Check Wi-Fi/mobile data and retry." else (e.message ?: "Unexpected error.")
                _state.update { it.copy(loading=false,operation=null,passwordBusy=false,error=msg) }
            } finally { _state.update { it.copy(loading=false) } }
        }
    }
    private fun InstanceDto.toVm(defaultZone: String) = Vm(
        name=name,status=status,zone=zone?.substringAfterLast('/') ?: defaultZone,
        machineType=machineType?.substringAfterLast('/') ?: "unknown",
        externalIp=networkInterfaces.flatMap { it.accessConfigs }.firstNotNullOfOrNull { it.natIP } ?: "",
        gpu=guestAccelerators.joinToString { "${it.acceleratorCount} × ${it.acceleratorType.substringAfterLast('/')}" }.ifBlank { "None" },
        tags=tags?.items.orEmpty(),id=id
    )
}

class CloudViewModelFactory(private val app: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = CloudViewModel(app) as T
}
