package com.example.gcpvmmanager.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightScheme = lightColorScheme(primary=Color(0xFF4559C7), secondary=Color(0xFF59627A), tertiary=Color(0xFF006B5B))
private val DarkScheme = darkColorScheme(primary=Color(0xFFB8C3FF), secondary=Color(0xFFC0C6DD), tertiary=Color(0xFF6ADCC2))
@Composable fun CloudTheme(content: @Composable () -> Unit) {
    val dark=isSystemInDarkTheme()
    val scheme=if(Build.VERSION.SDK_INT>=31) {
        if(dark) dynamicDarkColorScheme(androidx.compose.ui.platform.LocalContext.current) else dynamicLightColorScheme(androidx.compose.ui.platform.LocalContext.current)
    } else if(dark) DarkScheme else LightScheme
    MaterialTheme(colorScheme=scheme,typography=Typography(),content=content)
}
