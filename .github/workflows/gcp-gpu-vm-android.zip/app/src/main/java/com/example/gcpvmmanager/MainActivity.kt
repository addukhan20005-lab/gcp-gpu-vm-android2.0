package com.example.gcpvmmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.gcpvmmanager.ui.AppRoot
import com.example.gcpvmmanager.ui.CloudViewModel
import com.example.gcpvmmanager.ui.CloudViewModelFactory
import com.example.gcpvmmanager.ui.theme.CloudTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            val vm: CloudViewModel = viewModel(factory = CloudViewModelFactory(application))
            CloudTheme { AppRoot(vm) }
        }
    }
}
