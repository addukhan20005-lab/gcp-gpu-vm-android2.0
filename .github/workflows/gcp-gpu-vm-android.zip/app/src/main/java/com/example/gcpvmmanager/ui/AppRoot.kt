package com.example.gcpvmmanager.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.gcpvmmanager.auth.GoogleAuth
import com.example.gcpvmmanager.data.CostEstimates
import java.util.concurrent.TimeUnit

private const val PLAY_STORE_WINDOWS_APP = "https://play.google.com/store/apps/details?id=com.microsoft.rdc.androidx"

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AppRoot(vm: CloudViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context= LocalContext.current
    val activity=context as? Activity
    val snackbar= remember { SnackbarHostState() }
    var webClientId by remember { mutableStateOf("") }
    var zoneExpanded by remember { mutableStateOf(false) }
    var machineExpanded by remember { mutableStateOf(false) }
    var actionSheet by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var createRoute by remember { mutableStateOf(false) }
    var passwordRoute by remember { mutableStateOf(false) }
    var rdpRoute by remember { mutableStateOf(false) }
    var autoStopOptIn by remember { mutableStateOf(false) }
    val view=LocalView.current

    LaunchedEffect(s.message,s.error) {
        val msg=s.error ?: s.message
        if(!msg.isNullOrBlank()) snackbar.showSnackbar(msg)
    }
    BackHandler(passwordRoute) { vm.clearPassword(); passwordRoute=false }
    LaunchedEffect(passwordRoute) {
        if(passwordRoute) {
            activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE)
        } else activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
    DisposableEffect(Unit) { onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE); vm.clearPassword() } }

    val auth= remember { GoogleAuth(context) }
    Scaffold(
        snackbarHost={ SnackbarHost(snackbar) },
        topBar={ TopAppBar(
            title={ Column { Text("Cloud GPU VM Manager",fontWeight=FontWeight.Bold); Text("Your Google Cloud account",style=MaterialTheme.typography.labelSmall) } },
            actions={ if(s.signedIn) TextButton(onClick={vm.signOut()}) { Text("Sign out") } }
        ) },
        floatingActionButton={ if(s.signedIn && !createRoute && !passwordRoute && !rdpRoute) FloatingActionButton(onClick={createRoute=true}) { Icon(Icons.Default.Add,"Create VM") } }
    ) { padding ->
        NavHost(navController=rememberNavController(),startDestination="home",modifier=Modifier.padding(padding)) {
            composable("home") {
                LazyColumn(modifier=Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    item {
                        Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.errorContainer)) {
                            Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.Warning,null)
                                Column { Text("GPU VMs cost money",fontWeight=FontWeight.Bold); Text("This app does not provide free GPUs or free RDP. Billing must be enabled and you need GPU quota. Compute, Windows licensing, disks, IPs and network usage may be charged.") }
                            }
                        }
                    }
                    item {
                        ElevatedCard {
                            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                                Text("Google sign-in",style=MaterialTheme.typography.titleMedium)
                                OutlinedTextField(webClientId,{webClientId=it},label={Text("Web OAuth client ID")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                                Button(onClick={
                                    if(activity==null) { vm.updateMessage("Unable to access Android activity.") }
                                    else if(webClientId.isBlank()) vm.updateMessage("Enter the Web OAuth client ID from Google Cloud Console.")
                                    else {
                                        kotlinx.coroutines.MainScope().launch {
                                            try {
                                                val credential=auth.signIn(activity,webClientId)
                                                val access=auth.authorize(activity,credential.idToken)
                                                vm.setAuth(credential.idToken,access)
                                            } catch(e:Exception) { vm.updateMessage("Google authorization failed: ${e.message ?: "Please retry."}") }
                                        }
                                    }
                                },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Login,null); Spacer(Modifier.width(8.dp)); Text(if(s.signedIn)"Authorized" else "Sign in with Google") }
                                if(s.signedIn) Text("Access token is held in memory only.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                    item {
                        ElevatedCard { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            Text("Project & zone",style=MaterialTheme.typography.titleMedium)
                            OutlinedTextField(s.project,vm::updateProject,label={Text("Google Cloud Project ID")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                            ExposedDropdownMenuBox(expanded=zoneExpanded,onExpandedChange={zoneExpanded=it}) {
                                OutlinedTextField(s.zone,{vm.updateZone(it)},label={Text("Zone")},modifier=Modifier.fillMaxWidth().menuAnchor(),singleLine=true,trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(zoneExpanded)})
                                ExposedDropdownMenu(expanded=zoneExpanded,onDismissRequest={zoneExpanded=false}) {
                                    (listOf("us-central1-a","us-central1-b","us-east1-b","us-east1-c","us-west1-b","europe-west4-a","asia-south1-a") ).forEach { z -> DropdownMenuItem(text={Text(z)},onClick={vm.updateZone(z);zoneExpanded=false}) }
                                }
                            }
                            Text("You can type any zone into the field. VM list shows instances in this zone.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                Button(onClick={vm.persist();vm.refresh()},enabled=s.signedIn && s.project.isNotBlank()) { Icon(Icons.Default.Refresh,null); Spacer(Modifier.width(6.dp)); Text("Load / refresh") }
                                if(s.loading || s.operation!=null) CircularProgressIndicator(Modifier.size(24.dp),strokeWidth=2.dp)
                            }
                        } }
                    }
                    item { Text("Virtual machines (${s.vms.size})",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }
                    if(s.vms.isEmpty()) item { Text("No instances loaded. Sign in, enter a project ID and load the selected zone.",color=MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(s.vms,key={it.name}) { item ->
                        ElevatedCard(onClick={vm.selectVm(item);actionSheet=true}) {
                            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment=Alignment.CenterVertically) {
                                    Icon(Icons.Default.Computer,null,tint=MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) { Text(item.name,fontWeight=FontWeight.Bold); Text("${item.zone} · ${item.machineType}",style=MaterialTheme.typography.bodySmall) }
                                    AssistChip(onClick={vm.selectVm(item);actionSheet=true},label={Text(item.status)})
                                }
                                HorizontalDivider()
                                Text("External IP: ${item.externalIp.ifBlank { "Not assigned" }}",style=MaterialTheme.typography.bodyMedium)
                                Text("GPU: ${item.gpu}",style=MaterialTheme.typography.bodyMedium)
                                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) { TextButton(onClick={vm.selectVm(item);actionSheet=true}) { Text("Actions"); Icon(Icons.Default.MoreVert,null) } }
                            }
                        }
                    }
                    item {
                        ElevatedCard { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            Text("Cost helper",style=MaterialTheme.typography.titleMedium)
                            Text("Illustrative only: current create settings estimate about $${"%.2f".format(CostEstimates.estimate(s.machineType,s.gpu))}/hour. Real charges vary by region, Windows licensing, disk, network, discounts and Spot pricing.",style=MaterialTheme.typography.bodySmall)
                            Text("Reminder: stop VMs you are not using. Stopped VMs may still incur disk and other resource charges.",style=MaterialTheme.typography.bodyMedium)
                            OutlinedButton(onClick={
                                val req=OneTimeWorkRequestBuilder<StopReminderWorker>().setInitialDelay(4,TimeUnit.HOURS).build()
                                WorkManager.getInstance(context).enqueue(req)
                                vm.updateMessage("A stop reminder is scheduled for 4 hours. It will not stop a VM automatically.")
                            },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Notifications,null); Spacer(Modifier.width(8.dp)); Text("Schedule 4-hour stop reminder") }
                        } }
                    }
                    item { Spacer(Modifier.height(70.dp)) }
                }
            }
        }
    }

    if(createRoute) CreateVmDialog(s,vm,onClose={createRoute=false},onCreate={vm.create();createRoute=false},machineExpanded={machineExpanded},setMachineExpanded={machineExpanded=it})
    if(s.firewallDialog) FirewallDialog(s,vm)
    if(actionSheet && s.selectedVm!=null) ModalBottomSheet(onDismissRequest={actionSheet=false;vm.selectVm(null)}) {
        val item=s.selectedVm!!
        Column(Modifier.fillMaxWidth().padding(horizontal=20.dp).padding(bottom=30.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text(item.name,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
            Text("${item.status} · ${item.zone}",style=MaterialTheme.typography.bodySmall)
            Button(onClick={rdpRoute=true;actionSheet=false},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Launch,null); Spacer(Modifier.width(8.dp)); Text("Connect with RDP") }
            OutlinedButton(onClick={passwordRoute=true;actionSheet=false;vm.getWindowsPassword(item)},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Key,null); Spacer(Modifier.width(8.dp)); Text("Get Windows password") }
            if(item.status=="RUNNING") OutlinedButton(onClick={vm.action("stop",item);actionSheet=false},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Stop,null); Spacer(Modifier.width(8.dp)); Text("Stop VM") }
            else OutlinedButton(onClick={vm.action("start",item);actionSheet=false},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow,null); Spacer(Modifier.width(8.dp)); Text("Start VM") }
            OutlinedButton(onClick={vm.setFirewallDialog(true);actionSheet=false},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Security,null); Spacer(Modifier.width(8.dp)); Text("Configure RDP firewall") }
            Button(onClick={deleteDialog=true},colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error),modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Delete,null); Spacer(Modifier.width(8.dp)); Text("Delete VM") }
        }
    }
    if(deleteDialog && s.selectedVm!=null) AlertDialog(onDismissRequest={deleteDialog=false},title={Text("Delete ${s.selectedVm!!.name}?")},text={Text("This action cannot be undone. The VM's auto-delete boot disk will also be removed.")},confirmButton={TextButton(onClick={vm.action("delete",s.selectedVm!!);deleteDialog=false;actionSheet=false}) { Text("Delete",color=MaterialTheme.colorScheme.error) }},dismissButton={TextButton(onClick={deleteDialog=false}) { Text("Cancel") }})

    if(passwordRoute) AlertDialog(
        onDismissRequest={passwordRoute=false;vm.clearPassword()},
        title={Text("Windows password")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                if(s.passwordBusy) { CircularProgressIndicator(); Text("Generating RSA key, updating metadata and polling serial port 4. Windows setup can take several minutes.") }
                else if(s.passwordText!=null) {
                    var reveal by remember { mutableStateOf(false) }
                    OutlinedTextField(if(reveal)s.passwordText!! else "•".repeat(s.passwordText!!.length),{},label={Text("Password")},readOnly=true,modifier=Modifier.fillMaxWidth(),visualTransformation=VisualTransformation.None,trailingIcon={IconButton(onClick={reveal=!reveal}) { Icon(if(reveal)Icons.Default.VisibilityOff else Icons.Default.Visibility,null) }})
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick={reveal=!reveal}) { Text(if(reveal)"Hide" else "Show") }
                        TextButton(onClick={copySensitive(context,s.passwordText!!) ; vm.updateMessage("Password copied as sensitive clipboard content." )}) { Icon(Icons.Default.ContentCopy,null); Text("Copy") }
                    }
                } else Text("Password not available yet. Check the snackbar error and retry after Windows finishes initializing.")
            }
        },
        confirmButton={TextButton(onClick={passwordRoute=false;vm.clearPassword()}) { Text("Close & clear") }}
    )
    if(rdpRoute && s.selectedVm!=null) RdpDialog(s.selectedVm!!,context,onClose={rdpRoute=false})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun CreateVmDialog(s: UiState, vm: CloudViewModel, onClose:()->Unit, onCreate:()->Unit, machineExpanded:()->Boolean, setMachineExpanded:(Boolean)->Unit) {
    AlertDialog(onDismissRequest=onClose,title={Text("Create Windows VM")},text={
        Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Creates billable Windows Server 2022 resources in your project.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.error)
            OutlinedTextField(s.createName,vm::updateCreateName,label={Text("VM name")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            ExposedDropdownMenuBox(expanded=machineExpanded(),onExpandedChange={setMachineExpanded(it)}) {
                OutlinedTextField(s.machineType,{vm.updateMachine(it)},label={Text("Machine type")},modifier=Modifier.fillMaxWidth().menuAnchor(),readOnly=true,trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(machineExpanded())})
                ExposedDropdownMenu(expanded=machineExpanded(),onDismissRequest={setMachineExpanded(false)}) {
                    listOf("n1-standard-4","n1-standard-8").forEach { t -> DropdownMenuItem(text={Text(t)},onClick={vm.updateMachine(t);setMachineExpanded(false)}) }
                }
            }
            OutlinedTextField(s.diskGb,vm::updateDisk,label={Text("Boot disk size (GB, min 50)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            ToggleLine("NVIDIA Tesla T4 GPU","Requires regional GPU quota and capacity.",s.gpu,vm::updateGpu)
            ToggleLine("Spot VM","May be preempted; potentially lower cost.",s.spot,vm::updateSpot)
            Text("Image: projects/windows-cloud/global/images/family/windows-2022",style=MaterialTheme.typography.bodySmall)
            Text("Network tag: rdp",style=MaterialTheme.typography.bodySmall)
            Text("Estimated hourly price: ~$${"%.2f".format(CostEstimates.estimate(s.machineType,s.gpu))}/hour (editable estimate constants; not a quote).",fontWeight=FontWeight.Bold)
        }
    },confirmButton={Button(onClick=onCreate,enabled=!s.loading) { if(s.loading) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp) else Text("Create VM") }},dismissButton={TextButton(onClick=onClose) { Text("Cancel") }})
}
@Composable private fun ToggleLine(title:String,desc:String,checked:Boolean,onChange:(Boolean)->Unit) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.Medium); Text(desc,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant) }
        Switch(checked,onChange)
    }
}
@Composable private fun FirewallDialog(s: UiState,vm: CloudViewModel) {
    AlertDialog(onDismissRequest={vm.setFirewallDialog(false)},title={Text("RDP firewall rule")},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Allows TCP 3389 to VMs tagged rdp. Restricting to /32 is strongly recommended.",style=MaterialTheme.typography.bodySmall)
            Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(s.firewallRestrict,vm::updateFirewallRestrict); Text("Restrict to my public IP (/32)") }
            if(s.firewallRestrict) {
                OutlinedTextField(s.firewallIp,vm::updateFirewallIp,label={Text("Public IPv4 address")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                OutlinedButton(onClick={
                    kotlinx.coroutines.MainScope().launch {
                        try {
                            val ip=withContext(Dispatchers.IO) { java.net.URL("https://api.ipify.org").readText().trim() }
                            vm.updateFirewallIp(ip)
                        } catch(_:Exception) { vm.updateMessage("Could not detect public IP. Enter it manually.") }
                    }
                },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.MyLocation,null); Spacer(Modifier.width(8.dp)); Text("Detect current public IP") }
            } else Text("WARNING: This opens RDP to 0.0.0.0/0, allowing every IPv4 address to attempt a connection.",color=MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)
        }
    },confirmButton={Button(onClick={vm.createFirewall()}) { Text("Create / update rule") }},dismissButton={TextButton(onClick={vm.setFirewallDialog(false)}) { Text("Cancel") }})
}
@Composable private fun RdpDialog(vm: com.example.gcpvmmanager.data.Vm,context:Context,onClose:()->Unit) {
    AlertDialog(onDismissRequest=onClose,title={Text("Connect to ${vm.name}")},text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("External IP: ${vm.externalIp.ifBlank { "Not assigned" }}")
            OutlinedButton(onClick={copySensitive(context,vm.externalIp)},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy,null); Spacer(Modifier.width(8.dp)); Text("Copy IP") }
            Button(onClick={
                val uri=Uri.parse("rdp://full%20address=s:${vm.externalIp}:3389&username=s:vmuser")
                val intent=Intent(Intent.ACTION_VIEW,uri)
                if(intent.resolveActivity(context.packageManager)!=null) context.startActivity(intent)
                else context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(PLAY_STORE_WINDOWS_APP)))
            },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Launch,null); Spacer(Modifier.width(8.dp)); Text("Open RDP app") }
            OutlinedButton(onClick={
                val content="full address:s:${vm.externalIp}:3389\nusername:s:vmuser\nprompt for credentials:i:1\n"
                val intent=Intent(Intent.ACTION_SEND).apply { type="application/x-rdp"; putExtra(Intent.EXTRA_TITLE,"${vm.name}.rdp"); putExtra(Intent.EXTRA_TEXT,content) }
                context.startActivity(Intent.createChooser(intent,"Share .rdp connection details"))
            },modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Share,null); Spacer(Modifier.width(8.dp)); Text("Share .rdp file/details") }
            Text("The shared connection details do not include your password. RDP requires a running VM, Windows initialization, and a permitted firewall rule.",style=MaterialTheme.typography.bodySmall)
        }
    },confirmButton={TextButton(onClick=onClose) { Text("Done") }})
}
private fun copySensitive(context: Context,text:String) {
    val clipboard=context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip=ClipData.newPlainText("Sensitive Cloud VM credential",text)
    if(Build.VERSION.SDK_INT>=33) clip.description.extras=android.os.PersistableBundle().apply { putBoolean(ClipDescriptionExtras.IS_SENSITIVE,true) }
    clipboard.setPrimaryClip(clip)
}
private object ClipDescriptionExtras { const val IS_SENSITIVE="android.content.extra.IS_SENSITIVE" }
