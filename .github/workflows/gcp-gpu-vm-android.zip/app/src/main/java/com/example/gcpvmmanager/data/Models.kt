package com.example.gcpvmmanager.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable data class ApiError(val error: ApiErrorBody? = null)
@Serializable data class ApiErrorBody(val code: Int? = null, val message: String? = null, val errors: List<ApiErrorItem> = emptyList())
@Serializable data class ApiErrorItem(val reason: String? = null, val message: String? = null)

@Serializable data class InstanceList(val items: List<InstanceDto> = emptyList())
@Serializable data class InstanceDto(
    val id: String? = null, val name: String, val status: String = "UNKNOWN",
    val zone: String? = null, val machineType: String? = null,
    val networkInterfaces: List<NetworkInterfaceDto> = emptyList(),
    val guestAccelerators: List<AcceleratorDto> = emptyList(),
    val tags: TagsDto? = null, val metadata: MetadataDto? = null
)
@Serializable data class NetworkInterfaceDto(val accessConfigs: List<AccessConfigDto> = emptyList())
@Serializable data class AccessConfigDto(val natIP: String? = null)
@Serializable data class AcceleratorDto(val acceleratorCount: Int = 1, val acceleratorType: String = "")
@Serializable data class TagsDto(val items: List<String> = emptyList())
@Serializable data class MetadataDto(val fingerprint: String? = null, val items: List<MetadataItem> = emptyList())
@Serializable data class MetadataItem(val key: String, val value: String)
@Serializable data class OperationDto(val name: String, val status: String = "PENDING", val error: OperationError? = null)
@Serializable data class OperationError(val errors: List<OperationErrorItem> = emptyList())
@Serializable data class OperationErrorItem(val message: String? = null, val code: String? = null)
@Serializable data class InstanceCreateRequest(
    val name: String,
    val machineType: String,
    val disks: List<DiskConfig>,
    val networkInterfaces: List<NetworkConfig>,
    val guestAccelerators: List<GuestAccelerator>? = null,
    val tags: TagsDto,
    val metadata: MetadataDto,
    val scheduling: Scheduling
)
@Serializable data class DiskConfig(val boot: Boolean, val autoDelete: Boolean, val initializeParams: InitializeParams)
@Serializable data class InitializeParams(val sourceImage: String, val diskSizeGb: String, val diskType: String)
@Serializable data class NetworkConfig(val network: String, val accessConfigs: List<NetworkAccessConfig>)
@Serializable data class NetworkAccessConfig(val name: String, val type: String)
@Serializable data class GuestAccelerator(val acceleratorType: String, val acceleratorCount: Int)
@Serializable data class Scheduling(
    val onHostMaintenance: String,
    val automaticRestart: Boolean,
    val provisioningModel: String? = null,
    val instanceTerminationAction: String? = null
)
@Serializable data class MetadataRequest(val fingerprint: String?, val items: List<MetadataItem>)
@Serializable data class FirewallDto(
    val name: String, val description: String = "RDP access for rdp-tagged VMs",
    val direction: String = "INGRESS", val priority: Int = 1000,
    val network: String = "global/networks/default",
    val targetTags: List<String> = listOf("rdp"), val sourceRanges: List<String>,
    val allowed: List<FirewallAllowed>
)
@Serializable data class FirewallAllowed(val IPProtocol: String = "tcp", val ports: List<String> = listOf("3389"))
@Serializable data class FirewallList(val items: List<FirewallRule> = emptyList())
@Serializable data class FirewallRule(val name: String, val network: String? = null, val sourceRanges: List<String> = emptyList(), val targetTags: List<String> = emptyList())
@Serializable data class SerialOutput(val contents: String = "", val next: String? = null)

data class Vm(
    val name: String, val status: String, val zone: String, val machineType: String,
    val externalIp: String, val gpu: String, val tags: List<String>, val id: String? = null
)
