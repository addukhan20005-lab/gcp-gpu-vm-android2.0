package com.example.gcpvmmanager.ui

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.gcpvmmanager.R

class StopReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val manager=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel="vm_stop_reminders"
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(channel,"VM stop reminders",NotificationManager.IMPORTANCE_DEFAULT))
        val notification=NotificationCompat.Builder(applicationContext,channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Check your Google Cloud VM")
            .setContentText("Stop any VM you no longer need to help control costs.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("This reminder does not stop the VM automatically. Open Cloud GPU VM Manager and stop unused instances."))
            .setAutoCancel(true).build()
        manager.notify(4201,notification)
        return Result.success()
    }
}
