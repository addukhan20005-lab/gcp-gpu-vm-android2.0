package com.example.gcpvmmanager.data

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.*

private const val BASE_URL = "https://compute.googleapis.com/compute/v1/"
val JsonCodec = Json { ignoreUnknownKeys = true; explicitNulls = false }

interface ComputeApi {
    @GET("projects/{project}/zones/{zone}/instances")
    suspend fun listInstances(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String): Response<InstanceList>
    @GET("projects/{project}/zones/{zone}/instances/{name}")
    suspend fun getInstance(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("name") name: String): Response<InstanceDto>
    @POST("projects/{project}/zones/{zone}/instances")
    suspend fun createInstance(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Body body: InstanceCreateRequest): Response<OperationDto>
    @POST("projects/{project}/zones/{zone}/instances/{name}/start")
    suspend fun startInstance(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("name") name: String): Response<OperationDto>
    @POST("projects/{project}/zones/{zone}/instances/{name}/stop")
    suspend fun stopInstance(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("name") name: String): Response<OperationDto>
    @DELETE("projects/{project}/zones/{zone}/instances/{name}")
    suspend fun deleteInstance(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("name") name: String): Response<OperationDto>
    @GET("projects/{project}/zones/{zone}/operations/{operation}")
    suspend fun zoneOperation(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("operation") operation: String): Response<OperationDto>
    @GET("projects/{project}/global/operations/{operation}")
    suspend fun globalOperation(@Header("Authorization") auth: String, @Path("project") project: String, @Path("operation") operation: String): Response<OperationDto>
    @GET("projects/{project}/global/firewalls")
    suspend fun listFirewalls(@Header("Authorization") auth: String, @Path("project") project: String): Response<FirewallList>
    @POST("projects/{project}/global/firewalls")
    suspend fun createFirewall(@Header("Authorization") auth: String, @Path("project") project: String, @Body body: FirewallDto): Response<OperationDto>
    @PATCH("projects/{project}/global/firewalls/{name}")
    suspend fun patchFirewall(@Header("Authorization") auth: String, @Path("project") project: String, @Path("name") name: String, @Body body: FirewallDto): Response<OperationDto>
    @POST("projects/{project}/zones/{zone}/instances/{name}/setMetadata")
    suspend fun setMetadata(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("name") name: String, @Body body: MetadataRequest): Response<OperationDto>
    @GET("projects/{project}/zones/{zone}/instances/{name}/serialPort")
    suspend fun serialPort(@Header("Authorization") auth: String, @Path("project") project: String, @Path("zone") zone: String, @Path("name") name: String, @Query("port") port: Int = 4, @Query("start") start: Long? = null): Response<SerialOutput>
}

object ApiFactory {
    fun create(): ComputeApi {
        val client = OkHttpClient.Builder().build()
        val retrofit = Retrofit.Builder().baseUrl(BASE_URL).client(client)
            .addConverterFactory(retrofit2.converter.kotlinx.serialization.asConverterFactory(JsonCodec, "application/json".toMediaType()))
            .build()
        return retrofit.create(ComputeApi::class.java)
    }
}
