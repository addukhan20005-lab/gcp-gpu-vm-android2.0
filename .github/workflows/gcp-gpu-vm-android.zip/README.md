# Cloud GPU VM Manager (Android)

Native Android starter app using Kotlin, Jetpack Compose, Material 3, MVVM/StateFlow, Navigation Compose, Retrofit, kotlinx.serialization, DataStore, Credential Manager, Google Identity AuthorizationClient, and WorkManager. `minSdk = 26`.

> **Not free:** This app does not provide free GPUs or free RDP. GPU Windows VMs can incur compute, GPU, Windows licensing, disk, IP, and network charges. Billing must be enabled and the project needs regional GPU quota and capacity.

## What is included

- Google Credential Manager sign-in and Compute Engine scope authorization flow.
- In-memory access token and ID token only; non-secret project and zone settings in DataStore.
- List, create, start, stop and delete VM operations; operation polling.
- Windows Server 2022, N1 Standard 4/8, optional T4, Spot settings, disk minimum 50 GB, `rdp` network tag.
- TCP 3389 firewall rule with manual public IP `/32` restriction by default, optional IP detection on tap, and all-IPv4 warning.
- Browser/device-side RSA password retrieval attempt, local decryption, screenshot blocking in password dialog, sensitive clipboard flag.
- RDP intent, connection-details sharing, stop reminder notification.
- Editable estimate constants in `data/CostEstimates.kt`.

## 1. Create Google Cloud project and enable billing

1. In Google Cloud Console, create/select a project.
2. Attach a billing account. Confirm the project is active and billing is enabled.
3. Enable Compute Engine API:
   ```bash
   gcloud services enable compute.googleapis.com --project YOUR_PROJECT_ID
   ```
4. Ensure the Google user has the IAM permissions required to list/create/start/stop/delete instances, set instance metadata, and create/update firewall rules. Use least privilege.
5. In IAM & Admin → Quotas & System Limits, request NVIDIA T4 GPU quota for the region where you plan to create VMs. Also review regional CPU, disk, external IP, and address quotas.
6. Confirm the zone supports T4 and has capacity. Quota approval does not guarantee available capacity.

## 2. Configure OAuth consent and Android/Web clients

1. Open Google Cloud Console → Google Auth Platform (or APIs & Services → OAuth consent screen). Configure app branding, audience, required scopes and test users. For an External app in Testing, add your Google account as a test user.
2. Create an **Android OAuth client** with the exact application ID/package name `com.example.gcpvmmanager` and the SHA-1 certificate fingerprint for the signing key.
   - For debug builds, obtain the SHA-1 with Android Studio's Gradle `signingReport` task, or:
     ```bash
     ./gradlew signingReport
     ```
   - Register the SHA-1 shown under the `debug` variant. If you change `applicationId`, update the OAuth client too.
3. Create a **Web application OAuth client ID**. The app uses this as Credential Manager's `serverClientId` and displays a field for it at sign-in. Do not embed a client secret; only the public client ID belongs in the app.
4. Configure the Compute Engine OAuth scope `https://www.googleapis.com/auth/compute`. Depending on consent screen status and Google's current OAuth policies, sensitive/restricted scope verification or test-user constraints may apply.
5. This starter uses Credential Manager to obtain a Google ID token, then calls Identity AuthorizationClient for the Compute scope. On some project/account configurations, the authorization result may require user resolution/consent UI. The starter surfaces that case as an error; production-hardening should implement the current Google Identity API resolution intent flow rather than bypassing consent.
6. The Web client ID is public configuration, not a secret. Never add a Web client secret or service-account private key to the app.

## 3. Build the debug APK

Requirements: Android Studio with JDK 17 and Android SDK Platform 35.

```bash
./gradlew assembleDebug
```

On Windows PowerShell:
```powershell
.\gradlew.bat assembleDebug
```

Expected APK path:
`app/build/outputs/apk/debug/app-debug.apk`

If Gradle wrapper files are absent, open the project in Android Studio and use **File → Sync Project with Gradle Files**; Android Studio can generate wrapper files, or run `gradle wrapper` using a local Gradle installation.

## 4. Install on an Android device

Enable USB debugging, connect the device, then:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Alternatively, copy the APK to your device and open it, allowing installs from that source if Android asks. On Android 13+, request notification permission in system settings if reminders do not appear. This starter only declares `INTERNET` and `POST_NOTIFICATIONS` and does not include a runtime notification permission prompt yet.

## Usage

1. Enter the Web OAuth client ID and sign in.
2. Enter your project ID and zone; tap **Load / refresh**.
3. Create a Windows VM. T4 and Spot require suitable quota and use `onHostMaintenance=TERMINATE`. Spot also sets `provisioningModel=SPOT`, `automaticRestart=false`, and `instanceTerminationAction=STOP`.
4. Configure TCP 3389. Default is restricted to a user-confirmed public IP `/32`. The app detects the IP only when you tap the button; if detection fails, type it manually.
5. Open the VM action sheet to start, stop, delete, get the Windows password, or connect.
6. Stop unused VMs. Stopping does not eliminate persistent disk or all other resource costs.

## Security notes

- **Token handling:** OAuth access tokens and Google ID tokens are held in process memory only. The app does not write tokens or passwords to DataStore, files, logs, SharedPreferences, or backups. Signing out clears the in-memory references.
- **Backup:** `android:allowBackup="false"` is set in the manifest.
- **Private key:** RSA-2048 key pair is generated on-device. The private key is not sent to Google; only public modulus/exponent are added to instance metadata. Java/Android cannot guarantee physical zeroization of garbage-collected objects.
- **Password screen:** `FLAG_SECURE` is enabled while the password screen is open, then cleared when it closes or the activity is disposed. Clipboard is marked sensitive on supported Android versions.
- **Firewall:** RDP TCP 3389 is a high-value attack surface. Restrict source to a trusted public IPv4 `/32`; avoid `0.0.0.0/0`. Consider VPN/IAP/other hardened access patterns where suitable.
- **Minimal permissions:** only `INTERNET` and `POST_NOTIFICATIONS` are declared. Public IP detection uses an HTTPS request only when the user taps the detection button.
- **No backend/secrets:** all Compute Engine requests are made directly from the Android app to `compute.googleapis.com`; no service account or client secret is embedded.
- **No network logs:** don't add HTTP body/header logging interceptors; bearer tokens and password-related serial output are sensitive.
- **RDP sharing:** Android share sheet sends connection details only, not the Windows password.
- **Costs:** estimates in `CostEstimates.kt` are editable illustrative constants, not live pricing. Use the Google Cloud Pricing Calculator and current GPU pricing before creating resources.
- **Reminder behavior:** WorkManager schedules a notification reminder. This starter does not automatically stop a VM, even if the UI is later extended with an opt-in toggle; safe automated stopping needs a persisted resource identity and a deliberately re-authorized token strategy. It is not safe to persist access tokens just to support background stopping.

## Known limitations / validation required before production

This is a source starter, not a verified production client. Build and test with current Android Studio/Gradle and a real test project before using billable resources. Google OAuth authorization UI handling may require a production-complete resolution flow. Windows guest-agent metadata JSON/serial output can vary; the RSA password flow must be validated against the current Windows image. The current starter attempts to locate a matching modulus and encryptedPassword on serial port 4; test the exact guest-agent output before relying on it. The RDP share action shares connection details through Android's share sheet rather than producing a file URI. Firewall "update" patches a same-name rule; check existing rule configuration in Cloud Console if you use another network or rule name.
